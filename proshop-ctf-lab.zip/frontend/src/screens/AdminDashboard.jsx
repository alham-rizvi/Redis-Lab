// =============================================================================
// ProShop CTF Lab — Admin Dashboard (React)
// STAGE 4: Hidden admin panel with Product Image Importer (SSRF trigger)
// =============================================================================
import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';

const AdminDashboard = () => {
  const { userInfo } = useSelector((state) => state.auth);
  const navigate = useNavigate();

  const [dashboardData, setDashboardData] = useState(null);
  const [imageUrl, setImageUrl] = useState('');
  const [importResult, setImportResult] = useState(null);
  const [proxyUrl, setProxyUrl] = useState('');
  const [proxyMethod, setProxyMethod] = useState('GET');
  const [proxyBody, setProxyBody] = useState('');
  const [proxyResult, setProxyResult] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!userInfo || !userInfo.isAdmin) {
      navigate('/login');
      return;
    }
    fetch('/api/admin/dashboard', { credentials: 'include' })
      .then((r) => r.json())
      .then(setDashboardData);
  }, [userInfo, navigate]);

  // ── Image Importer (SSRF-001 trigger) ──────────────────────────────────────
  const handleImageImport = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch('/api/admin/import-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ imageUrl }),
      });
      const data = await res.json();
      setImportResult(data);
    } catch (err) {
      setImportResult({ error: err.message });
    }
    setLoading(false);
  };

  // ── Internal Proxy (SSRF-002 trigger) ──────────────────────────────────────
  const handleProxy = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      let bodyObj = {};
      if (proxyBody) {
        try { bodyObj = JSON.parse(proxyBody); } catch { bodyObj = proxyBody; }
      }
      const res = await fetch('/api/admin/internal-proxy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ url: proxyUrl, method: proxyMethod, body: bodyObj }),
      });
      const data = await res.json();
      setProxyResult(data);
    } catch (err) {
      setProxyResult({ error: err.message });
    }
    setLoading(false);
  };

  const boxStyle = { border: '1px solid #aaa', padding: 16, marginBottom: 20, borderRadius: 6 };

  return (
    <div style={{ padding: 24, fontFamily: 'monospace' }}>
      <h1>🛠 Admin Dashboard</h1>

      {dashboardData && (
        <div style={boxStyle}>
          <h3>System Info</h3>
          <pre>{JSON.stringify(dashboardData, null, 2)}</pre>
        </div>
      )}

      {/* ── Product Image Importer ─────────────────────────────────────────
        SSRF Entry Point — imageUrl is fetched server-side without validation
        Players use this to probe internal services:
          http://127.0.0.1:6000/status
          http://127.0.0.1:6000/plugin/list
      ─────────────────────────────────────────────────────────────────── */}
      <div style={boxStyle}>
        <h3>📦 Remote Product Image Importer</h3>
        <p style={{ color: '#888' }}>Import product images from remote URLs for the catalogue.</p>
        <form onSubmit={handleImageImport}>
          <input
            type="text"
            value={imageUrl}
            onChange={(e) => setImageUrl(e.target.value)}
            placeholder="https://example.com/product-image.jpg"
            style={{ width: 400 }}
          />
          <button type="submit" disabled={loading}>
            {loading ? 'Fetching...' : 'Import Image'}
          </button>
        </form>
        {importResult && (
          <pre style={{ background: '#f0f0f0', padding: 8, marginTop: 8, overflow: 'auto' }}>
            {JSON.stringify(importResult, null, 2)}
          </pre>
        )}
      </div>

      {/* ── Internal Service Proxy ─────────────────────────────────────────
        Advanced SSRF relay — send arbitrary POST bodies to internal URLs
        Used to call POST /plugin/install on the internal service
      ─────────────────────────────────────────────────────────────────── */}
      <div style={boxStyle}>
        <h3>🔗 Remote Logistics Sync (Internal Proxy)</h3>
        <p style={{ color: '#888' }}>Sync with logistics partners and internal services.</p>
        <form onSubmit={handleProxy}>
          <div>
            <label>URL: </label>
            <input
              type="text"
              value={proxyUrl}
              onChange={(e) => setProxyUrl(e.target.value)}
              placeholder="http://internal-service/endpoint"
              style={{ width: 350 }}
            />
            <select value={proxyMethod} onChange={(e) => setProxyMethod(e.target.value)}>
              <option>GET</option>
              <option>POST</option>
              <option>PUT</option>
            </select>
          </div>
          <div style={{ marginTop: 8 }}>
            <label>Body (JSON): </label>
            <textarea
              rows="3"
              cols="60"
              value={proxyBody}
              onChange={(e) => setProxyBody(e.target.value)}
              placeholder='{"key": "value"}'
            />
          </div>
          <button type="submit" disabled={loading}>
            {loading ? 'Sending...' : 'Send Request'}
          </button>
        </form>
        {proxyResult && (
          <pre style={{ background: '#f0f0f0', padding: 8, marginTop: 8, overflow: 'auto' }}>
            {JSON.stringify(proxyResult, null, 2)}
          </pre>
        )}
      </div>
    </div>
  );
};

export default AdminDashboard;
