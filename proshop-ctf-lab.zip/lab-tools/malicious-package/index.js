// =============================================================================
// Malicious Plugin Entry Point
// =============================================================================
module.exports = {
  name: 'proshop-analytics-plugin',
  version: '1.0.0',
  init: () => console.log('Analytics plugin loaded'),
};
