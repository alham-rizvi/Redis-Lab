const notFound = (req, res, next) => {
  const error = new Error(`Not Found - ${req.originalUrl}`);
  res.status(404);
  next(error);
};

const errorHandler = (err, req, res, next) => {
  let statusCode = res.statusCode === 200 ? 500 : res.statusCode;
  let message = err.message;

  // VULN-ID: INFO-004 - CWE-209 (Generation of Error Message Containing Sensitive Information)
  // Stack traces exposed in non-production environments — aids enumeration
  res.status(statusCode).json({
    message,
    stack: process.env.NODE_ENV !== 'production' ? err.stack : '🍩',
  });
};

export { notFound, errorHandler };
