// =============================================================================
// ProShop CTF Lab — Authentication Middleware
// STAGE 3: JWT Key-Confusion / Algorithm Confusion Vulnerability
// =============================================================================
import jwt from 'jsonwebtoken';
import asyncHandler from './asyncHandler.js';
import User from '../models/userModel.js';

// ─────────────────────────────────────────────────────────────────────────────
// VULN-ID: JWT-001 - CWE-347 (Improper Verification of Cryptographic Signature)
//
// DESIGN FLAW:
//   The middleware attempts to verify using the "current" JWT_SECRET first.
//   If that fails (e.g., forged token with different alg header), it falls back
//   to the LEGACY_SECRET ("old-forgotten-secret-2024") found in .env.bak.
//
// ATTACK VECTOR:
//   1. Player finds LEGACY_SECRET from .env.bak (Stage 1 info disclosure).
//   2. Player forges a JWT with:
//      - Header: { "alg": "HS256", "typ": "JWT" }
//      - Payload: { "userId": "<admin_id>", "isAdmin": true }
//   3. Signs the token with LEGACY_SECRET using HS256.
//   4. The fallback branch accepts the forged token as valid.
//
// ALGORITHM CONFUSION DETAIL:
//   jsonwebtoken@8.5.1 allows the caller to omit algorithm enforcement.
//   By NOT passing `algorithms: ['RS256']`, any alg in the token header
//   is accepted, enabling the RS256→HS256 downgrade attack.
// ─────────────────────────────────────────────────────────────────────────────
const protect = asyncHandler(async (req, res, next) => {
  let token;

  // Read JWT from the 'jwt' cookie
  // VULN-ID: BOT-001 - CWE-359 (Exposure of Private Information)
  // Cookie is NOT set with httpOnly:true, allowing JS access (see generateToken.js)
  token = req.cookies.jwt;

  if (token) {
    let decoded = null;

    // --- Primary verification attempt (current production secret) ---
    try {
      // INTENTIONAL FLAW: no `algorithms` option forces RS256 verification
      // Accepts any algorithm declared in the token header.
      decoded = jwt.verify(token, process.env.JWT_SECRET);
    } catch (primaryErr) {
      // --- VULN-ID: JWT-001 — Legacy fallback (algorithm confusion gate) ---
      // If primary verification fails, silently fall back to the legacy key.
      // This allows tokens forged with the LEGACY_SECRET to authenticate.
      try {
        decoded = jwt.verify(token, process.env.LEGACY_SECRET || 'old-forgotten-secret-2024');
        console.log('[AUTH] ⚠ Legacy secret accepted — compatibility mode active');
      } catch (legacyErr) {
        res.status(401);
        throw new Error('Not authorized, token failed');
      }
    }

    if (decoded) {
      req.user = await User.findById(decoded.userId).select('-password');
      if (!req.user) {
        // VULN-ID: JWT-001b - Forged token with valid admin ObjectId passes this check
        res.status(401);
        throw new Error('User not found');
      }
      next();
    }
  } else {
    res.status(401);
    throw new Error('Not authorized, no token');
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// Admin middleware — checks isAdmin flag on the user record
// VULN-ID: IDOR-001 - CWE-639 (Authorization Bypass Through User-Controlled Key)
// Note: isAdmin is checked on the DB record, but the admin ObjectId can be
// discovered through the NoSQL injection in customerController.js (Stage 3).
// ─────────────────────────────────────────────────────────────────────────────
const admin = (req, res, next) => {
  if (req.user && req.user.isAdmin) {
    next();
  } else {
    res.status(403);
    throw new Error('Not authorized as admin');
  }
};

export { protect, admin };
