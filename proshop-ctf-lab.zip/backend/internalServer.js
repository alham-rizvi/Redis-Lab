// =============================================================================
// ProShop CTF Lab — Internal Microservice Server
// STAGE 5: RCE via Plugin Installer (loopback-only, port 6000)
// =============================================================================
import express from 'express';
import { exec } from 'child_process';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const app = express();
app.use(express.json());

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PLUGIN_DIR = path.join(__dirname, '../plugins');
if (!fs.existsSync(PLUGIN_DIR)) fs.mkdirSync(PLUGIN_DIR, { recursive: true });

// ─────────────────────────────────────────────────────────────────────────────
// VULN-ID: RCE-001 - CWE-78 (OS Command Injection via child_process.exec)
// VULN-ID: RCE-002 - CWE-94 (Code Injection via npm postinstall lifecycle)
//
// DESIGN FLAW:
//   The `packageName` parameter is injected unsanitized into a shell command
//   string. An attacker can break out of the npm install command using shell
//   metacharacters (`;`, `&&`, `|`) or craft a malicious package.json with
//   a `postinstall` hook that runs arbitrary OS commands.
//
// ATTACK VECTORS:
//   1. Direct Command Injection:
//      POST /plugin/install  { "packageName": "lodash; powershell -nop -w hidden -e BASE64" }
//
//   2. Postinstall Hook (via malicious package tarball):
//      POST /plugin/install  { "packageName": "file:///tmp/malicious-package" }
//      where malicious-package/package.json contains:
//        "scripts": { "postinstall": "powershell -nop -w hidden -e BASE64" }
//
// WINDOWS TARGETING (Stage 6):
//   The payload builder detects the OS and crafts either:
//     - cmd.exe /c <command>       (Windows CMD)
//     - powershell.exe -nop -w hidden -e <B64>  (PowerShell stager)
//     - bash -c <command>          (Linux/fallback)
// ─────────────────────────────────────────────────────────────────────────────

// @route   GET /status
// Discoverable via SSRF — confirms internal service is alive and reveals routes
app.get('/status', (req, res) => {
  res.json({
    service: 'ProShop Internal Plugin Manager',
    version: '1.2.0',
    os: process.platform,
    node: process.version,
    endpoints: [
      'GET  /status',
      'GET  /plugin/list',
      'POST /plugin/install',
      'POST /plugin/exec',   // undocumented debug endpoint
    ],
  });
});

// @route   GET /plugin/list
// Lists installed plugins from the plugin directory
app.get('/plugin/list', (req, res) => {
  try {
    const plugins = fs.readdirSync(PLUGIN_DIR).map((name) => ({
      name,
      path: path.join(PLUGIN_DIR, name),
    }));
    res.json({ plugins });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// @route   POST /plugin/install
// ─────────────────────────────────────────────────────────────────────────────
// PRIMARY RCE ENTRY POINT
//
// packageName is concatenated directly into a shell command.
// There is NO input validation, NO shell escaping, NO allowlist.
// ─────────────────────────────────────────────────────────────────────────────
app.post('/plugin/install', (req, res) => {
  const { packageName, version = 'latest' } = req.body;

  if (!packageName) {
    return res.status(400).json({ error: 'packageName required' });
  }

  // INTENTIONAL: unsanitized string concatenation → OS command injection
  const installCmd = `npm install ${packageName}@${version} --prefix "${PLUGIN_DIR}"`;

  console.log(`[INTERNAL] Installing plugin: ${installCmd}`);

  // exec() spawns a shell — allows ; && | metacharacter injection
  exec(installCmd, { cwd: PLUGIN_DIR, shell: true }, (err, stdout, stderr) => {
    if (err) {
      return res.status(500).json({
        error: err.message,
        stderr,
        stdout,
        cmd: installCmd,  // reflects command back — useful for blind injection debug
      });
    }
    res.json({
      message: 'Plugin installed successfully',
      stdout,
      stderr,
      installedPath: path.join(PLUGIN_DIR, packageName),
    });
  });
});

// @route   POST /plugin/exec
// ─────────────────────────────────────────────────────────────────────────────
// VULN-ID: RCE-003 - CWE-78 (Direct OS Command Execution — Undocumented Debug)
//
// Undocumented debug endpoint discovered via /status route enumeration.
// Executes arbitrary commands directly. Windows-aware: detects OS and
// wraps payload in PowerShell stager with base64 encoding.
// ─────────────────────────────────────────────────────────────────────────────
app.post('/plugin/exec', (req, res) => {
  const { cmd, usePs = false } = req.body;

  if (!cmd) {
    return res.status(400).json({ error: 'cmd required' });
  }

  let finalCmd;

  if (process.platform === 'win32') {
    if (usePs) {
      // Build PowerShell base64 stager for Windows
      const psCmd = `powershell.exe -NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -Command "${cmd}"`;
      const b64 = Buffer.from(cmd, 'utf16le').toString('base64');
      // VULN-ID: RCE-004 - CWE-78 (PowerShell stager with base64 bypass)
      finalCmd = `powershell.exe -NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -EncodedCommand ${b64}`;
    } else {
      finalCmd = `cmd.exe /c ${cmd}`;
    }
  } else {
    finalCmd = `/bin/bash -c "${cmd}"`;
  }

  exec(finalCmd, { shell: true, timeout: 15000 }, (err, stdout, stderr) => {
    res.json({
      platform: process.platform,
      cmd: finalCmd,
      stdout: stdout || '',
      stderr: stderr || '',
      exitCode: err ? err.code : 0,
    });
  });
});

// Bind ONLY to loopback — external connections are refused
const PORT = process.env.INTERNAL_PORT || 6000;
app.listen(PORT, '127.0.0.1', () => {
  console.log(`[INTERNAL] Plugin service listening on 127.0.0.1:${PORT}`);
  console.log(`[INTERNAL] This service is NOT accessible from external networks.`);
});
