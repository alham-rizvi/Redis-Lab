// =============================================================================
// ProShop CTF Lab — Customer / Support Ticket Controller
// STAGE 3: IDOR + NoSQL Injection to discover hidden admin route
// =============================================================================
import asyncHandler from '../middleware/asyncHandler.js';
import SupportTicket from '../models/supportTicketModel.js';
import User from '../models/userModel.js';

// @desc    Create support ticket
// @route   POST /api/support
// @access  Private
const createTicket = asyncHandler(async (req, res) => {
  const { subject, message } = req.body;
  const ticket = await SupportTicket.create({
    user: req.user._id,
    subject,
    message,
  });
  res.status(201).json(ticket);
});

// @desc    Get ticket by ticketId
// @route   GET /api/support/:ticketId
// @access  Private
// ─────────────────────────────────────────────────────────────────────────────
// VULN-ID: IDOR-001 - CWE-639 (Authorization Bypass Through User-Controlled Key)
//
// The endpoint uses sequential numeric `ticketId` (1000, 1001, 1002…).
// The ownership check only applies when the user is NOT an admin.
// A player who forges an admin token (Stage 3 JWT confusion) can enumerate
// all tickets by iterating ticketId — including ticket #1000 which is an
// internal admin ticket revealing the hidden dashboard route.
//
// Ticket #1000 internalNote:
//   "Internal: Admin dashboard moved to /api/admin/dashboard
//    Plugin management at /api/admin/plugins
//    Internal service reachable at http://127.0.0.1:6000"
// ─────────────────────────────────────────────────────────────────────────────
const getTicketById = asyncHandler(async (req, res) => {
  // VULN-ID: NOSQLI-001 - CWE-943 (NoSQL Injection)
  //
  // The ticketId parameter is used directly in a MongoDB query without
  // type coercion. Sending: GET /api/support/{"$gt":999}
  // causes Mongoose to interpret it as an operator object, returning
  // the first ticket with ticketId > 999 — i.e., the admin ticket #1000.
  //
  // curl -H "Cookie: jwt=<forged>" "http://localhost:5000/api/support/%7B%22%24gt%22%3A999%7D"
  const rawId = req.params.ticketId;

  let queryId;
  try {
    // Unsafe: JSON.parse allows operator injection
    queryId = JSON.parse(rawId);
  } catch {
    queryId = rawId;
  }

  const ticket = await SupportTicket.findOne({ ticketId: queryId });

  if (!ticket) {
    res.status(404);
    throw new Error('Ticket not found');
  }

  // IDOR: ownership only checked for non-admin users
  if (!req.user.isAdmin && ticket.user.toString() !== req.user._id.toString()) {
    res.status(403);
    throw new Error('Not authorized to view this ticket');
  }

  res.json(ticket);
});

// @desc    Get my tickets
// @route   GET /api/support
// @access  Private
const getMyTickets = asyncHandler(async (req, res) => {
  const tickets = await SupportTicket.find({ user: req.user._id });
  res.json(tickets);
});

// @desc    Update ticket status (Admin)
// @route   PUT /api/support/:ticketId
// @access  Private/Admin
const updateTicketStatus = asyncHandler(async (req, res) => {
  const ticket = await SupportTicket.findOne({
    ticketId: Number(req.params.ticketId),
  });

  if (!ticket) {
    res.status(404);
    throw new Error('Ticket not found');
  }

  ticket.status = req.body.status || ticket.status;
  ticket.internalNote = req.body.internalNote || ticket.internalNote;

  const updated = await ticket.save();
  res.json(updated);
});

export { createTicket, getTicketById, getMyTickets, updateTicketStatus };
