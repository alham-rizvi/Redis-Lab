// =============================================================================
// ProShop CTF Lab — Admin Controller
// STAGE 4: SSRF via Product Image Importer
// =============================================================================
import asyncHandler from '../middleware/asyncHandler.js';
import fetch from 'node-fetch';
import Product from '../models/productModel.js';

// @desc    Admin dashboard overview
// @route   GET /api/admin/dashboard
// @access  Private/Admin
const getDashboard = asyncHandler(async (req, res) => {
  const productCount = await Product.countDocuments();
  res.json({
    message: 'Admin Dashboard Active',
    productCount,
    internalService: 'http://127.0.0.1:6000 (loopback only)',
    pluginEndpoint: 'POST /api/admin/plugins/install',
    // Breadcrumb hint for players
    hint: 'Remote Logistics Sync available at POST /api/admin/import-image',
  });
});

// @desc    Import product image from remote URL
// @route   POST /api/admin/import-image
// @access  Private/Admin
// ─────────────────────────────────────────────────────────────────────────────
// VULN-ID: SSRF-001 - CWE-918 (Server-Side Request Forgery)
//
// The `imageUrl` parameter is fetched server-side without ANY validation.
// No blocklist of loopback addresses (127.0.0.1, ::1, 0.0.0.0).
// No CIDR range checks (RFC-1918 private ranges 10.x, 172.16.x, 192.168.x).
// No DNS rebinding protection.
//
// Attack: POST /api/admin/import-image
// Payload: { "imageUrl": "http://127.0.0.1:6000/status" }
//   → Proxies the request through the server to the internal service
//   → Exposes internal endpoints not accessible from the outside
//
// Escalation: { "imageUrl": "http://127.0.0.1:6000/plugin/install" }
//   → Hits the RCE-capable plugin installer on the internal service
// ─────────────────────────────────────────────────────────────────────────────
const importProductImage = asyncHandler(async (req, res) => {
  const { imageUrl, productId } = req.body;

  if (!imageUrl) {
    res.status(400);
    throw new Error('imageUrl is required');
  }

  // INTENTIONAL: No URL validation, no blocklist check
  let response;
  try {
    response = await fetch(imageUrl, {
      method: 'GET',
      timeout: 8000,
    });
  } catch (err) {
    res.status(502);
    throw new Error(`Failed to fetch remote URL: ${err.message}`);
  }

  const contentType = response.headers.get('content-type') || '';
  const body = await response.text();

  // Return raw server response (allows reading internal service output)
  res.json({
    statusCode: response.status,
    contentType,
    body: body.substring(0, 4096), // max 4KB of response
    imageUrl,
  });
});

// @desc    Proxy arbitrary request to internal service (SSRF pivot helper)
// @route   POST /api/admin/internal-proxy
// @access  Private/Admin
// ─────────────────────────────────────────────────────────────────────────────
// VULN-ID: SSRF-002 - CWE-918 (Secondary SSRF — POST relay)
//
// Allows the player to POST arbitrary JSON bodies to internal service endpoints
// via the SSRF pivot. This is needed to trigger the plugin installer RCE.
// ─────────────────────────────────────────────────────────────────────────────
const internalProxy = asyncHandler(async (req, res) => {
  const { url, method = 'GET', body: proxyBody } = req.body;

  if (!url) {
    res.status(400);
    throw new Error('url is required');
  }

  // INTENTIONAL: No URL restriction
  const options = {
    method,
    headers: { 'Content-Type': 'application/json' },
    timeout: 10000,
  };

  if (proxyBody && method !== 'GET') {
    options.body = JSON.stringify(proxyBody);
  }

  const response = await fetch(url, options);
  const text = await response.text();

  res.json({
    status: response.status,
    body: text,
  });
});

// @desc    List installed plugins
// @route   GET /api/admin/plugins
// @access  Private/Admin
const listPlugins = asyncHandler(async (req, res) => {
  // Proxies to internal service plugin list
  const response = await fetch('http://127.0.0.1:6000/plugin/list');
  const data = await response.json();
  res.json(data);
});

export { getDashboard, importProductImage, internalProxy, listPlugins };
