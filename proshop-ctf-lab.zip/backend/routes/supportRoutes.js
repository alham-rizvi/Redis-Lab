import express from 'express';
import {
  createTicket,
  getTicketById,
  getMyTickets,
  updateTicketStatus,
} from '../controllers/customerController.js';
import { protect, admin } from '../middleware/authMiddleware.js';

const router = express.Router();

router.route('/').get(protect, getMyTickets).post(protect, createTicket);
router
  .route('/:ticketId')
  .get(protect, getTicketById)      // IDOR + NoSQL injection entry point
  .put(protect, admin, updateTicketStatus);

export default router;
