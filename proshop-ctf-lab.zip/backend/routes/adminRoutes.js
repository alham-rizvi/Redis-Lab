import express from 'express';
import {
  getDashboard,
  importProductImage,
  internalProxy,
  listPlugins,
} from '../controllers/adminController.js';
import { protect, admin } from '../middleware/authMiddleware.js';

const router = express.Router();

// All admin routes require both protect (JWT) and admin (isAdmin flag)
router.get('/dashboard', protect, admin, getDashboard);
router.post('/import-image', protect, admin, importProductImage);  // SSRF-001
router.post('/internal-proxy', protect, admin, internalProxy);     // SSRF-002
router.get('/plugins', protect, admin, listPlugins);

export default router;
