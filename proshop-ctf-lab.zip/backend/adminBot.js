// =============================================================================
// ProShop CTF Lab — Admin Bot (Headless Browser)
// STAGE 2: Simulated privileged admin with accessible JWT cookie
// =============================================================================
//
// This script simulates a privileged administrator who:
//   1. Logs in with hardcoded credentials to obtain a valid JWT session cookie
//   2. Periodically visits the product review pages to "moderate" new reviews
//   3. Stores the JWT in a cookie accessible to JavaScript (httpOnly: false)
//
// The XSS payload in Stage 2 exfiltrates this cookie to the player's collector.
//
// Run: node backend/adminBot.js
//
// VULN-ID: BOT-001 - CWE-359 (Exposure of Private Information — JWT in JS-readable cookie)
// =============================================================================

import puppeteer from 'puppeteer';

const TARGET_BASE = process.env.TARGET_URL || 'http://localhost:3000';
const ADMIN_EMAIL = 'admin@proshop.com';
const ADMIN_PASS  = 'Admin1234!';
const VISIT_INTERVAL_MS = 60_000; // Visit every 60 seconds

// Product IDs to visit (seeded products — admin reviews these pages)
// Players need to POST their XSS payload to one of these products
const PRODUCT_REVIEW_PATHS = [
  '/product/PRODUCT_ID_1',
  '/product/PRODUCT_ID_2',
  '/product/PRODUCT_ID_3',
];

let browser;
let page;

async function launchBrowser() {
  browser = await puppeteer.launch({
    headless: true,
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-dev-shm-usage',
    ],
  });
  page = await browser.newPage();
  console.log('[BOT] Browser launched');
}

async function adminLogin() {
  console.log('[BOT] Logging in as admin...');
  await page.goto(`${TARGET_BASE}/login`, { waitUntil: 'networkidle2' });

  await page.type('input[name="email"]', ADMIN_EMAIL);
  await page.type('input[name="password"]', ADMIN_PASS);
  await page.click('button[type="submit"]');

  await page.waitForNavigation({ waitUntil: 'networkidle2' });

  // Verify login succeeded
  const cookies = await page.cookies();
  const jwtCookie = cookies.find((c) => c.name === 'jwt');

  if (jwtCookie) {
    console.log(`[BOT] Authenticated. JWT cookie obtained (httpOnly=${jwtCookie.httpOnly})`);
    // NOTE: httpOnly is FALSE — this cookie is readable by document.cookie from XSS
  } else {
    console.error('[BOT] Login FAILED — no JWT cookie found');
    process.exit(1);
  }
}

async function visitProductPages() {
  for (const path of PRODUCT_REVIEW_PATHS) {
    try {
      const url = `${TARGET_BASE}${path}`;
      console.log(`[BOT] Visiting: ${url}`);
      await page.goto(url, { waitUntil: 'networkidle2', timeout: 20000 });
      // Dwell for 3 seconds to allow XSS payload execution
      await new Promise((r) => setTimeout(r, 3000));
    } catch (err) {
      console.error(`[BOT] Error visiting ${path}: ${err.message}`);
    }
  }
}

async function runBotLoop() {
  await launchBrowser();
  await adminLogin();

  // Initial visit
  await visitProductPages();

  // Repeat every 60 seconds
  setInterval(async () => {
    console.log('[BOT] Periodic review check...');
    try {
      // Re-login if session expired
      const cookies = await page.cookies();
      if (!cookies.find((c) => c.name === 'jwt')) {
        await adminLogin();
      }
      await visitProductPages();
    } catch (err) {
      console.error(`[BOT] Loop error: ${err.message}`);
      // Try to recover by re-launching
      await browser.close();
      await launchBrowser();
      await adminLogin();
    }
  }, VISIT_INTERVAL_MS);
}

runBotLoop().catch(console.error);
