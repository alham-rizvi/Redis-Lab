// =============================================================================
// ProShop CTF Lab — Seed Script
// STAGE 6: Populates MongoDB with required structural records
// =============================================================================
import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import dotenv from 'dotenv';
import User from './models/userModel.js';
import Product from './models/productModel.js';
import SupportTicket from './models/supportTicketModel.js';
import connectDB from './config/db.js';

dotenv.config();
connectDB();

// ─── Sample Users ─────────────────────────────────────────────────────────────
const users = [
  {
    name: 'Admin User',
    email: 'admin@proshop.com',
    password: bcrypt.hashSync('Admin1234!', 10),
    isAdmin: true,
  },
  {
    name: 'John Doe',
    email: 'john@example.com',
    password: bcrypt.hashSync('Password123!', 10),
    isAdmin: false,
  },
  {
    name: 'Jane Smith',
    email: 'jane@example.com',
    password: bcrypt.hashSync('Password123!', 10),
    isAdmin: false,
  },
];

// ─── Sample Products ──────────────────────────────────────────────────────────
const buildProducts = (adminId) => [
  {
    name: 'Airpods Wireless Bluetooth Headphones',
    image: '/images/airpods.jpg',
    description: 'Bluetooth technology lets you connect wirelessly...',
    brand: 'Apple',
    category: 'Electronics',
    price: 89.99,
    countInStock: 10,
    rating: 4.5,
    numReviews: 12,
    user: adminId,
    reviews: [],
  },
  {
    name: 'iPhone 11 Pro 256GB Memory',
    image: '/images/phone.jpg',
    description: 'Introducing the iPhone 11 Pro...',
    brand: 'Apple',
    category: 'Electronics',
    price: 599.99,
    countInStock: 7,
    rating: 4.0,
    numReviews: 8,
    user: adminId,
    reviews: [],
  },
  {
    name: 'Cannon EOS 80D DSLR Camera',
    image: '/images/camera.jpg',
    description: 'Characterized by versatility...',
    brand: 'Canon',
    category: 'Electronics',
    price: 929.99,
    countInStock: 5,
    rating: 3,
    numReviews: 12,
    user: adminId,
    reviews: [],
  },
];

// ─── Seeder ───────────────────────────────────────────────────────────────────
const seedData = async () => {
  try {
    await User.deleteMany();
    await Product.deleteMany();
    await SupportTicket.deleteMany();

    const createdUsers = await User.insertMany(users);
    const adminUser = createdUsers[0];

    const sampleProducts = buildProducts(adminUser._id);
    const createdProducts = await Product.insertMany(sampleProducts);

    // ── Seed support tickets ─────────────────────────────────────────────────
    // Ticket #1000 is the admin internal ticket revealing hidden routes
    // This is discovered via IDOR (Stage 3)
    const tickets = [
      {
        ticketId: 1000,
        user: adminUser._id,
        subject: '[INTERNAL] Infrastructure Notes Q4 2024',
        message: 'Internal deployment memo — do not share externally.',
        // VULN-ID: IDOR-001 — internalNote reveals hidden admin route
        internalNote:
          'INTERNAL: Admin dashboard at /api/admin/dashboard. ' +
          'Plugin management endpoint: POST /api/admin/internal-proxy. ' +
          'Internal plugin service reachable at http://127.0.0.1:6000. ' +
          'Plugin installer: POST /plugin/install with {packageName}. ' +
          'Debug exec endpoint: POST /plugin/exec with {cmd, usePs}.',
        isAdminTicket: true,
        status: 'closed',
      },
      {
        ticketId: 1001,
        user: createdUsers[1]._id,
        subject: 'Order not received',
        message: 'I placed order #1234 two weeks ago and have not received it.',
        internalNote: '',
        status: 'open',
      },
      {
        ticketId: 1002,
        user: createdUsers[2]._id,
        subject: 'Refund request',
        message: 'I would like a refund for my recent order.',
        internalNote: '',
        status: 'open',
      },
    ];

    await SupportTicket.insertMany(tickets);

    console.log('✅ Data seeded successfully!');
    console.log(`   Admin account  : admin@proshop.com / Admin1234!`);
    console.log(`   Admin ObjectId : ${adminUser._id}`);
    console.log(`   Products seeded: ${createdProducts.length}`);
    console.log(`   Product IDs for adminBot.js:`);
    createdProducts.forEach((p) => console.log(`     - ${p._id}  (${p.name})`));
    console.log('\n⚠  Update PRODUCT_REVIEW_PATHS in adminBot.js with the above IDs\n');

    process.exit();
  } catch (err) {
    console.error(`❌ Seed error: ${err.message}`);
    process.exit(1);
  }
};

const destroyData = async () => {
  try {
    await User.deleteMany();
    await Product.deleteMany();
    await SupportTicket.deleteMany();
    console.log('🗑  All data destroyed');
    process.exit();
  } catch (err) {
    console.error(`❌ Destroy error: ${err.message}`);
    process.exit(1);
  }
};

if (process.argv[2] === '-d') {
  destroyData();
} else {
  seedData();
}
