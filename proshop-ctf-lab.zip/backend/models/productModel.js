import mongoose from 'mongoose';

// =============================================================================
// ProShop CTF Lab — Product Model
// STAGE 2: Stored XSS — Raw HTML stored in review.comment field
// =============================================================================

// ─────────────────────────────────────────────────────────────────────────────
// VULN-ID: XSS-001 - CWE-79 (Improper Neutralization of Input During Web Page Generation)
//
// The `comment` field in the review sub-document stores raw, unsanitized user
// input directly into MongoDB. No sanitization library (e.g., DOMPurify,
// xss-clean) is applied at write time. The React frontend renders this field
// via dangerouslySetInnerHTML, completing the Stored XSS sink.
// ─────────────────────────────────────────────────────────────────────────────
const reviewSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    rating: { type: Number, required: true },
    // RAW HTML — NO SANITIZATION APPLIED
    comment: { type: String, required: true },
    user: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: 'User',
    },
  },
  { timestamps: true }
);

const productSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: 'User',
    },
    name: { type: String, required: true },
    image: { type: String, required: true },
    brand: { type: String, required: true },
    category: { type: String, required: true },
    description: { type: String, required: true },
    reviews: [reviewSchema],
    rating: { type: Number, required: true, default: 0 },
    numReviews: { type: Number, required: true, default: 0 },
    price: { type: Number, required: true, default: 0 },
    countInStock: { type: Number, required: true, default: 0 },
  },
  { timestamps: true }
);

const Product = mongoose.model('Product', productSchema);
export default Product;
