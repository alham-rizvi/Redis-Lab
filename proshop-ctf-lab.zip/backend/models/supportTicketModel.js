import mongoose from 'mongoose';

// =============================================================================
// ProShop CTF Lab — Support Ticket Model
// STAGE 3: IDOR + NoSQL Injection target
// =============================================================================

const supportTicketSchema = new mongoose.Schema(
  {
    // VULN-ID: IDOR-001 - CWE-639 (Authorization Bypass Through User-Controlled Key)
    // Sequential numeric ticketId is guessable — used in IDOR attack
    ticketId: { type: Number, unique: true },
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    subject: { type: String, required: true },
    message: { type: String, required: true },
    // Hidden internal notes only admins should see
    internalNote: { type: String, default: '' },
    status: {
      type: String,
      enum: ['open', 'closed', 'escalated'],
      default: 'open',
    },
    isAdminTicket: { type: Boolean, default: false },
  },
  { timestamps: true }
);

// Auto-increment ticketId
supportTicketSchema.pre('save', async function (next) {
  if (this.isNew) {
    const lastTicket = await this.constructor.findOne({}, {}, { sort: { ticketId: -1 } });
    this.ticketId = lastTicket ? lastTicket.ticketId + 1 : 1000;
  }
  next();
});

const SupportTicket = mongoose.model('SupportTicket', supportTicketSchema);
export default SupportTicket;
