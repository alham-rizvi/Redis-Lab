// =============================================================================
// ProShop CTF Lab — Token Generator
// VULN-ID: BOT-001 - CWE-359 — httpOnly deliberately set to FALSE
// =============================================================================
import jwt from 'jsonwebtoken';

const generateToken = (res, userId) => {
  const token = jwt.sign({ userId }, process.env.JWT_SECRET, {
    expiresIn: '30d',
  });

  // INTENTIONAL VULNERABILITY: httpOnly is false
  // This means the cookie IS readable via document.cookie from JavaScript.
  // Combined with the Stored XSS in product reviews, this enables
  // the XSS payload to exfiltrate the admin's JWT to the collector.
  res.cookie('jwt', token, {
    httpOnly: false,   // <-- VULN: should be true in production
    secure: process.env.NODE_ENV !== 'development',
    sameSite: 'strict',
    maxAge: 30 * 24 * 60 * 60 * 1000,
  });
};

export default generateToken;
