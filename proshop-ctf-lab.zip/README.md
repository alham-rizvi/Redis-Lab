# ProShop CTF Lab — Hard Difficulty

> A deliberately vulnerable MERN-stack e-commerce application based on [ProShop v2](https://github.com/bradtraversy/proshop-v2).  
> Designed for advanced penetration testing training and CTF competitions.  
> **Target: Windows host RCE via 18-step exploit chain.**

---

## ⚠️ Legal Warning
This lab is **intentionally insecure**. Run it only in an isolated network environment. Never expose it to the internet. It is designed exclusively for legal security research and education.

---

## Architecture

```
[Player Browser]
     │ :3000 (React) / :5000 (API)
     ▼
[Windows Target Host]
  ├─ Express API          :5000   (external)
  ├─ React Frontend       :3000   (external)
  ├─ MongoDB              :27017  (localhost only)
  └─ Internal Service     :6000   (127.0.0.1 ONLY — SSRF pivot target)
```

## Vulnerability Chain

| Stage | ID | CWE | Type |
|-------|----|-----|------|
| 1 | INFO-001 | CWE-312 | `.env.bak` leaks `LEGACY_SECRET` |
| 1 | INFO-002 | CWE-538 | `package.json.old` exposes internal routes |
| 2 | XSS-001  | CWE-79  | Stored XSS in product reviews |
| 2 | BOT-001  | CWE-359 | Admin bot uses JS-accessible JWT cookie |
| 3 | JWT-001  | CWE-347 | Algorithm confusion → HS256 fallback |
| 3 | IDOR-001 | CWE-639 | Sequential ticket IDs + ownership bypass |
| 3 | NOSQLI-001 | CWE-943 | NoSQL injection via `JSON.parse` |
| 4 | SSRF-001 | CWE-918 | Unvalidated URL in image importer |
| 4 | SSRF-002 | CWE-918 | POST relay to internal service |
| 5 | RCE-001  | CWE-78  | Command injection via `packageName` |
| 5 | RCE-002  | CWE-94  | `postinstall` hook in malicious package |
| 5 | RCE-003  | CWE-78  | Undocumented `/plugin/exec` endpoint |
| 6 | RCE-004  | CWE-78  | PowerShell Base64 stager (Windows) |

---

## Quick Start

### Prerequisites
- Node.js 18+
- MongoDB running locally
- (Windows target) PowerShell 5.1+

### Installation
```bash
# Install backend dependencies
npm install

# Install frontend dependencies
cd frontend && npm install && cd ..

# Seed the database
npm run seed

# Note the Product IDs output by seed.js
# Update PRODUCT_REVIEW_PATHS in backend/adminBot.js with those IDs
```

### Running the Lab
```bash
# Terminal 1: Main API server
npm start

# Terminal 2: Internal plugin microservice (port 6000)
npm run internal

# Terminal 3: Admin bot (visits product pages every 60s)
npm run bot

# Terminal 4: React frontend (if running dev mode)
cd frontend && npm start
```

---

## Deliverables

| File | Purpose |
|------|---------|
| `backend/server.js` | Main Express app |
| `backend/internalServer.js` | RCE-capable internal service (loopback) |
| `backend/adminBot.js` | Headless browser admin simulation |
| `backend/seed.js` | Database seeder with flag tickets |
| `backend/middleware/authMiddleware.js` | JWT algorithm confusion |
| `backend/controllers/productController.js` | Stored XSS |
| `backend/controllers/customerController.js` | IDOR + NoSQLi |
| `backend/controllers/adminController.js` | SSRF |
| `frontend/src/screens/ProductScreen.jsx` | XSS dangerouslySetInnerHTML sink |
| `frontend/src/screens/AdminDashboard.jsx` | SSRF trigger UI |
| `.env.bak` | INFO: Leaked legacy secret |
| `package.json.old` | INFO: Internal routes exposed |
| `lab-tools/collector.js` | XSS cookie collector server |
| `lab-tools/forge_token.js` | JWT algorithm confusion exploit (Node) |
| `lab-tools/forge_token.py` | JWT algorithm confusion exploit (Python) |
| `lab-tools/malicious-package/` | Supply-chain RCE package |
| `docs/WRITEUP-v2-hard.md` | **Full 18-phase walkthrough** |

---

## Playing the Lab

Start at **Phase 1** of [`docs/WRITEUP-v2-hard.md`](docs/WRITEUP-v2-hard.md).

**Estimated completion time:** 3–6 hours for experienced players.

**Difficulty curve:**
```
Recon (easy) → XSS+Bot (medium) → JWT forge (hard) → SSRF (hard) → RCE (very hard)
```
